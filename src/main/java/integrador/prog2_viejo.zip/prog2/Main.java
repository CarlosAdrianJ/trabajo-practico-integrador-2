package integrador.prog2;

import integrador.prog2.config.ConexionDB;
import integrador.prog2.ui.MenuPrincipal;

import java.sql.Connection;

public class Main {
    public static void main(String[] args) {
        MenuPrincipal menuPrincipal = new MenuPrincipal();
        menuPrincipal.iniciar();
    }
}