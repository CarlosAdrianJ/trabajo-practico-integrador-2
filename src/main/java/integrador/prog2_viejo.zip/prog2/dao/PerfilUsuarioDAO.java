package integrador.prog2.dao;

import integrador.prog2.config.ConexionDB;
import integrador.prog2.entities.PerfilUsuario;
import integrador.prog2.exception.BusinessException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PerfilUsuarioDAO implements IBaseDAO<PerfilUsuario> {

    @Override
    public PerfilUsuario crear(PerfilUsuario perfil) {
        String sql = """
                INSERT INTO perfil_usuario (direccion, ciudad, dni, observaciones)
                VALUES (?, ?, ?, ?)
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, perfil.getDireccion());
            ps.setString(2, perfil.getCiudad());
            ps.setString(3, perfil.getDni());
            ps.setString(4, perfil.getObservaciones());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    perfil.setId(rs.getLong(1));
                }
            }

            return perfil;

        } catch (SQLException e) {
            throw new BusinessException("Error creando perfil de usuario. Revise que el DNI no esté repetido.", e);
        }
    }

    public PerfilUsuario crear(PerfilUsuario perfil, Connection con) {
        String sql = """
                INSERT INTO perfil_usuario (direccion, ciudad, dni, observaciones)
                VALUES (?, ?, ?, ?)
                """;

        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, perfil.getDireccion());
            ps.setString(2, perfil.getCiudad());
            ps.setString(3, perfil.getDni());
            ps.setString(4, perfil.getObservaciones());

            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    perfil.setId(rs.getLong(1));
                }
            }

            return perfil;

        } catch (SQLException e) {
            throw new BusinessException("Error creando perfil de usuario dentro de la transacción.", e);
        }
    }

    @Override
    public List<PerfilUsuario> listar() {
        String sql = """
                SELECT id, direccion, ciudad, dni, observaciones, eliminado, created_at
                FROM perfil_usuario
                WHERE eliminado = false
                ORDER BY id
                """;

        List<PerfilUsuario> perfiles = new ArrayList<>();

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                perfiles.add(mapearPerfilUsuario(rs));
            }

            return perfiles;

        } catch (SQLException e) {
            throw new BusinessException("Error listando perfiles de usuario.", e);
        }
    }

    @Override
    public Optional<PerfilUsuario> buscarPorId(Long id) {
        String sql = """
                SELECT id, direccion, ciudad, dni, observaciones, eliminado, created_at
                FROM perfil_usuario
                WHERE id = ?
                AND eliminado = false
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearPerfilUsuario(rs));
                }
            }

            return Optional.empty();

        } catch (SQLException e) {
            throw new BusinessException("Error buscando perfil de usuario por id.", e);
        }
    }

    public Optional<PerfilUsuario> buscarPorDni(String dni) {
        String sql = """
                SELECT id, direccion, ciudad, dni, observaciones, eliminado, created_at
                FROM perfil_usuario
                WHERE dni = ?
                AND eliminado = false
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dni);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapearPerfilUsuario(rs));
                }
            }

            return Optional.empty();

        } catch (SQLException e) {
            throw new BusinessException("Error buscando perfil de usuario por DNI.", e);
        }
    }

    @Override
    public PerfilUsuario actualizar(PerfilUsuario perfil) {
        String sql = """
                UPDATE perfil_usuario
                SET direccion = ?,
                    ciudad = ?,
                    dni = ?,
                    observaciones = ?
                WHERE id = ?
                AND eliminado = false
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, perfil.getDireccion());
            ps.setString(2, perfil.getCiudad());
            ps.setString(3, perfil.getDni());
            ps.setString(4, perfil.getObservaciones());
            ps.setLong(5, perfil.getId());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas == 0) {
                throw new BusinessException("No se pudo actualizar el perfil. Verifique que exista.");
            }

            return perfil;

        } catch (SQLException e) {
            throw new BusinessException("Error actualizando perfil de usuario. Revise que el DNI no esté repetido.", e);
        }
    }

    @Override
    public void eliminar(Long id) {
        String sql = """
                UPDATE perfil_usuario
                SET eliminado = true
                WHERE id = ?
                AND eliminado = false
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, id);

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas == 0) {
                throw new BusinessException("No se pudo eliminar el perfil. Verifique que exista.");
            }

        } catch (SQLException e) {
            throw new BusinessException("Error eliminando perfil de usuario.", e);
        }
    }

    public boolean existeDni(String dni) {
        String sql = """
                SELECT COUNT(*) AS total
                FROM perfil_usuario
                WHERE dni = ?
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dni);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }

            return false;

        } catch (SQLException e) {
            throw new BusinessException("Error validando DNI del perfil de usuario.", e);
        }
    }

    public boolean existeDniEnOtroPerfil(String dni, Long idPerfil) {
        String sql = """
                SELECT COUNT(*) AS total
                FROM perfil_usuario
                WHERE dni = ?
                AND id <> ?
                """;

        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, dni);
            ps.setLong(2, idPerfil);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total") > 0;
                }
            }

            return false;

        } catch (SQLException e) {
            throw new BusinessException("Error validando DNI del perfil de usuario.", e);
        }
    }

    private PerfilUsuario mapearPerfilUsuario(ResultSet rs) throws SQLException {
        PerfilUsuario perfil = new PerfilUsuario();

        perfil.setId(rs.getLong("id"));
        perfil.setDireccion(rs.getString("direccion"));
        perfil.setCiudad(rs.getString("ciudad"));
        perfil.setDni(rs.getString("dni"));
        perfil.setObservaciones(rs.getString("observaciones"));
        perfil.setEliminado(rs.getBoolean("eliminado"));

        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            perfil.setCreatedAt(createdAt.toLocalDateTime());
        }

        return perfil;
    }
}