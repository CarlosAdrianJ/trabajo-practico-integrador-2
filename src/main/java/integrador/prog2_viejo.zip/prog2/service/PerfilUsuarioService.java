package integrador.prog2.service;

import integrador.prog2.config.ConexionDB;
import integrador.prog2.dao.PerfilUsuarioDAO;
import integrador.prog2.dao.UsuarioDAO;
import integrador.prog2.entities.PerfilUsuario;
import integrador.prog2.entities.Usuario;
import integrador.prog2.exception.BusinessException;
import integrador.prog2.exception.EntityNotFoundException;
import integrador.prog2.exception.ValidationException;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class PerfilUsuarioService {

    private final PerfilUsuarioDAO perfilUsuarioDAO;
    private final UsuarioDAO usuarioDAO;
    private final UsuarioService usuarioService;

    public PerfilUsuarioService() {
        this.perfilUsuarioDAO = new PerfilUsuarioDAO();
        this.usuarioDAO = new UsuarioDAO();
        this.usuarioService = new UsuarioService();
    }

    public List<PerfilUsuario> listar() {
        return perfilUsuarioDAO.listar();
    }

    public PerfilUsuario buscarPorId(Long id) {
        validarId(id);

        return perfilUsuarioDAO.buscarPorId(id)
                .orElseThrow(() -> new EntityNotFoundException("Perfil de usuario", id));
    }

    public PerfilUsuario buscarPorDni(String dni) {
        validarDni(dni);

        String dniNormalizado = dni.trim();

        return perfilUsuarioDAO.buscarPorDni(dniNormalizado)
                .orElseThrow(() -> new EntityNotFoundException("Perfil de usuario con DNI", null));
    }

    public PerfilUsuario crear(
            String direccion,
            String ciudad,
            String dni,
            String observaciones
    ) {
        validarDireccion(direccion);
        validarCiudad(ciudad);
        validarDni(dni);

        String dniNormalizado = dni.trim();

        if (perfilUsuarioDAO.existeDni(dniNormalizado)) {
            throw new BusinessException("Ya existe un perfil de usuario con ese DNI.");
        }

        PerfilUsuario perfil = new PerfilUsuario(
                direccion.trim(),
                ciudad.trim(),
                dniNormalizado,
                normalizarTextoOpcional(observaciones)
        );

        return perfilUsuarioDAO.crear(perfil);
    }

    public PerfilUsuario crearYAsociarAUsuario(
            Long usuarioId,
            String direccion,
            String ciudad,
            String dni,
            String observaciones
    ) {
        validarId(usuarioId);
        validarDireccion(direccion);
        validarCiudad(ciudad);
        validarDni(dni);

        Usuario usuario = usuarioService.buscarPorId(usuarioId);

        if (usuario.getPerfilUsuario() != null || usuarioDAO.tienePerfil(usuarioId)) {
            throw new BusinessException("El usuario ya tiene un perfil asociado.");
        }

        String dniNormalizado = dni.trim();

        if (perfilUsuarioDAO.existeDni(dniNormalizado)) {
            throw new BusinessException("Ya existe un perfil de usuario con ese DNI.");
        }

        Connection con = null;

        try {
            con = ConexionDB.getConexion();
            con.setAutoCommit(false);

            PerfilUsuario perfil = new PerfilUsuario(
                    direccion.trim(),
                    ciudad.trim(),
                    dniNormalizado,
                    normalizarTextoOpcional(observaciones)
            );

            perfilUsuarioDAO.crear(perfil, con);

            usuarioDAO.asociarPerfil(usuarioId, perfil.getId(), con);

            con.commit();

            return perfil;

        } catch (Exception e) {
            hacerRollback(con);
            throw new BusinessException("Error creando y asociando perfil de usuario. La operación fue revertida.", e);
        } finally {
            cerrarConexion(con);
        }
    }

    public PerfilUsuario actualizar(
            Long id,
            String nuevaDireccion,
            String nuevaCiudad,
            String nuevoDni,
            String nuevasObservaciones
    ) {
        validarId(id);

        PerfilUsuario perfil = buscarPorId(id);

        if (nuevaDireccion != null && !nuevaDireccion.trim().isEmpty()) {
            perfil.setDireccion(nuevaDireccion.trim());
        }

        if (nuevaCiudad != null && !nuevaCiudad.trim().isEmpty()) {
            perfil.setCiudad(nuevaCiudad.trim());
        }

        if (nuevoDni != null && !nuevoDni.trim().isEmpty()) {
            validarDni(nuevoDni);

            String dniNormalizado = nuevoDni.trim();

            if (perfilUsuarioDAO.existeDniEnOtroPerfil(dniNormalizado, id)) {
                throw new BusinessException("Ya existe otro perfil de usuario con ese DNI.");
            }

            perfil.setDni(dniNormalizado);
        }

        if (nuevasObservaciones != null) {
            perfil.setObservaciones(normalizarTextoOpcional(nuevasObservaciones));
        }

        return perfilUsuarioDAO.actualizar(perfil);
    }

    public void eliminar(Long id) {
        validarId(id);

        buscarPorId(id);

        perfilUsuarioDAO.eliminar(id);
    }

    public boolean existeDni(String dni) {
        validarDni(dni);
        return perfilUsuarioDAO.existeDni(dni.trim());
    }

    private void validarId(Long id) {
        if (id == null || id <= 0) {
            throw new ValidationException("El id debe ser un número mayor que cero.");
        }
    }

    private void validarDireccion(String direccion) {
        if (direccion == null || direccion.trim().isEmpty()) {
            throw new ValidationException("La dirección del perfil no puede estar vacía.");
        }
    }

    private void validarCiudad(String ciudad) {
        if (ciudad == null || ciudad.trim().isEmpty()) {
            throw new ValidationException("La ciudad del perfil no puede estar vacía.");
        }
    }

    private void validarDni(String dni) {
        if (dni == null || dni.trim().isEmpty()) {
            throw new ValidationException("El DNI del perfil no puede estar vacío.");
        }
    }

    private String normalizarTextoOpcional(String texto) {
        if (texto == null || texto.trim().isEmpty()) {
            return null;
        }

        return texto.trim();
    }

    private void hacerRollback(Connection con) {
        if (con != null) {
            try {
                con.rollback();
            } catch (SQLException ignored) {
            }
        }
    }

    private void cerrarConexion(Connection con) {
        if (con != null) {
            try {
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException ignored) {
            }
        }
    }
}